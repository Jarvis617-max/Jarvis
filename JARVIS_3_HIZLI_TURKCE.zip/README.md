# JARVIS 3.0 — Hızlı Türkçe AI

JARVIS 3.0; Android arayüzü + Node/Express backend ile çalışan, Türkçe odaklı kişisel AI asistanıdır.

## Eklenenler
- Hızlı ve sade Claude/ChatGPT tarzı mobil arayüz
- Güçlü Türkçe sistem talimatları
- Güncel web araştırması aç/kapat
- Görsel yükleme ve analiz
- Türkçe konuşma ile giriş
- Türkçe sesli okuma
- Oturum bazlı konuşma hafızası
- Açıkça istenen bilgileri (`Hatırla: ...`) kalıcı hafızaya alma
- Herkese açık sosyal profil arama bağlantıları
- Backend URL ayarı
- Yeni sohbet düğmesi
- GitHub Actions ile APK derleme

## APK
Bu ZIP kaynak projedir; telefona doğrudan kurulmaz. GitHub Actions workflow'u çalıştırıldığında `app-debug.apk` artifact olarak oluşur.

## Backend
`backend/.env.example` dosyasını `.env` olarak kopyala ve `OPENAI_API_KEY` değerini ekle. API anahtarını uygulamanın içine koyma.

Varsayılan model: `gpt-5.6-sol`. Hesabında erişimi olan başka bir model gerekiyorsa `OPENAI_MODEL` ile değiştirilebilir.

## Güvenlik
Üretimde HTTPS, kimlik doğrulama, rate limit ve güvenli secret yönetimi kullan. Özel hesaplara veya özel mesajlara erişim/bypass eklenmez.
