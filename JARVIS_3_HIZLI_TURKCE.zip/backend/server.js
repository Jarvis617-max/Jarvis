import "dotenv/config";
import express from "express";
import cors from "cors";
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import OpenAI from "openai";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.use(cors());
app.use(express.json({ limit: "12mb" }));
const PORT = Number(process.env.PORT || 3000);
const MODEL = process.env.OPENAI_MODEL || "gpt-5.6-sol";
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const memFile = path.join(__dirname, "data/memory.json");
const chatFile = path.join(__dirname, "data/conversations.json");

async function read(file, fallback) { try { return JSON.parse(await fs.readFile(file, "utf8")); } catch { return fallback; } }
async function write(file, data) { await fs.writeFile(file, JSON.stringify(data, null, 2), "utf8"); }
function trim(x, n = 12000) { return String(x ?? "").trim().slice(0, n); }

function instructions(memory) {
  const m = Object.entries(memory).map(([k, v]) => `- ${k}: ${v}`).join("\n") || "- Hafıza boş.";
  return `Sen JARVIS'sin: hızlı, doğal ve güvenilir kişisel yapay zekâ asistanısın.
Önceliğin: doğru cevap + hızlı cevap + anlaşılır Türkçe.
Varsayılan dil Türkçedir; kullanıcı başka dil isterse o dile geç.
Gereksiz uzun girişler yapma. Basit sorulara kısa ve doğrudan cevap ver; karmaşık işlerde adım adım ilerle.
Güncel/değişebilir veya doğrulanması gereken bilgilerde web search kullan ve mümkün olduğunda kaynakları belirt.
Kullanıcının açıkça "hatırla", "kaydet", "bunu unutma" dediği bilgileri kalıcı hafıza için uygun gör; gizli/şifre gibi hassas sırları kaydetme.
Sosyal profil aramalarında yalnızca herkese açık bilgileri kullan. Kullanıcı adı eşleşmesini kimlik doğrulaması gibi sunma.
Özel hesaplara, özel mesajlara, parolalara veya erişim kısıtlamalarını aşmaya çalışma.
Görsel gönderilirse görseldeki içeriği dikkatle analiz et; görmediğin ayrıntıları uydurma.
Kullanıcı istemedikçe "ben bir yapay zekâyım" gibi gereksiz açıklamalar yapma.
Kayıtlı hafıza:
${m}`;
}

async function maybeRemember(message, memory) {
  const m = trim(message, 1000);
  const match = m.match(/^(?:hatırla|unutma|kaydet)\s*[:,-]?\s*(.+)$/iu);
  if (!match) return memory;
  const value = trim(match[1], 500);
  if (!value || /şifre|parola|password|token|api key|apikey/i.test(value)) return memory;
  memory.last_explicit_note = value;
  await write(memFile, memory);
  return memory;
}

app.get("/api/health", (q, s) => s.json({ ok: true, model: MODEL, language: "tr-TR" }));
app.get("/api/memory", async (q, s) => s.json({ memory: await read(memFile, {}) }));
app.delete("/api/memory", async (q, s) => { await write(memFile, {}); s.json({ ok: true }); });

app.get("/api/social/:username", (q, s) => {
  const u = trim(q.params.username, 100).replace(/^@+/, "");
  const domains = [
    ["Instagram", "instagram.com"], ["TikTok", "tiktok.com"], ["YouTube", "youtube.com"],
    ["X", "x.com"], ["Facebook", "facebook.com"], ["LinkedIn", "linkedin.com"],
    ["Reddit", "reddit.com"], ["Telegram", "t.me"]
  ];
  s.json({ username: u, results: domains.map(([platform, domain]) => ({
    platform,
    profile: `https://${domain}/${platform === "TikTok" ? "@" : ""}${encodeURIComponent(u)}`,
    search: `https://www.google.com/search?q=${encodeURIComponent(`site:${domain} "${u}"`)}`
  })) });
});

app.post("/api/chat", async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) return res.status(500).json({ error: "OPENAI_API_KEY eksik" });
    const sid = trim(req.body?.sessionId, 120) || "default";
    const message = trim(req.body?.message);
    if (!message && !req.body?.image) return res.status(400).json({ error: "message veya image gerekli" });
    let memory = await read(memFile, {});
    memory = await maybeRemember(message, memory);
    const chats = await read(chatFile, {});
    const history = Array.isArray(chats[sid]) ? chats[sid] : [];
    const input = [...history.slice(-20), { role: "user", content: message || "Bu görseli analiz et." }];

    if (req.body?.image) {
      input[input.length - 1] = {
        role: "user",
        content: [
          { type: "input_text", text: message || "Bu görseli analiz et." },
          { type: "input_image", image_url: req.body.image }
        ]
      };
    }

    const payload = {
      model: MODEL,
      instructions: instructions(memory),
      input,
      store: true
    };
    if (req.body?.useWeb !== false) payload.tools = [{ type: "web_search" }];

    const r = await client.responses.create(payload);
    const answer = r.output_text || "Yanıt üretilemedi.";
    chats[sid] = [...history, { role: "user", content: message || "[Görsel]" }, { role: "assistant", content: answer }].slice(-40);
    await write(chatFile, chats);
    res.json({ ok: true, answer, model: MODEL });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: e.message || "JARVIS hatası" });
  }
});

app.listen(PORT, () => console.log(`JARVIS backend http://localhost:${PORT}`));
