package com.jarvis.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.Locale

private val Activity.dataStore by preferencesDataStore("jarvis_settings")
private val Bg = Color(0xFF0B0B0B)
private val Panel = Color(0xFF151515)
private val TextMain = Color(0xFFF2F2EF)
private val Muted = Color(0xFF969690)
private val Accent = Color(0xFFD8D8D0)

data class Msg(val role: String, val text: String)

class MainActivity : ComponentActivity() {
    private val client = OkHttpClient()
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale("tr", "TR") }
        setContent {
            JarvisScreen(
                send = { text, image, web -> sendToJarvis(text, image, web) },
                speak = { speak(it) },
                saveBackend = { saveBackend(it) },
                getBackend = { loadBackend() }
            )
        }
    }

    private fun speak(text: String) { tts?.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null, "jarvis") }

    private fun saveBackend(url: String) {
        lifecycleScope.launch { dataStore.edit { it[stringPreferencesKey("backend")] = url.trim().removeSuffix("/") } }
    }

    private suspend fun loadBackend(): String =
        dataStore.data.first()[stringPreferencesKey("backend")] ?: "http://10.0.2.2:3000"

    private fun sendToJarvis(text: String, imageBase64: String?, useWeb: Boolean) {
        lifecycleScope.launch {
            try {
                val base = loadBackend()
                val bodyJson = JSONObject()
                    .put("sessionId", "android-" + android.provider.Settings.Secure.getString(contentResolver, android.provider.Settings.Secure.ANDROID_ID))
                    .put("message", text)
                    .put("useWeb", useWeb)
                if (imageBase64 != null) bodyJson.put("image", imageBase64)
                val body = bodyJson.toString().toRequestBody("application/json".toMediaType())
                val req = Request.Builder().url("$base/api/chat").post(body).build()
                val res = client.newCall(req).execute()
                val raw = res.body?.string().orEmpty()
                if (!res.isSuccessful) throw Exception(JSONObject(raw).optString("error", "Sunucu hatası"))
                val answer = JSONObject(raw).optString("answer", "Yanıt yok.")
                (application as? JarvisAppState)?.finishAnswer(answer)
            } catch (e: Exception) {
                (application as? JarvisAppState)?.finishAnswer("Bağlantı kurulamadı: ${e.message ?: "Bilinmeyen hata"}")
            }
        }
    }

    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}

class JarvisAppState : android.app.Application() {
    var onAnswer: ((String) -> Unit)? = null
    var onBusy: ((Boolean) -> Unit)? = null
    fun startAnswer() { runOnUiThread { onBusy?.invoke(true) } }
    fun finishAnswer(s: String) { runOnUiThread { onBusy?.invoke(false); onAnswer?.invoke(s) } }
    private fun runOnUiThread(block: () -> Unit) { android.os.Handler(mainLooper).post(block) }
}

@Composable
fun JarvisScreen(
    send: (String, String?, Boolean) -> Unit,
    speak: (String) -> Unit,
    saveBackend: (String) -> Unit,
    getBackend: suspend () -> String
) {
    val context = LocalContext.current
    val app = context.applicationContext as JarvisAppState
    var input by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(listOf<Msg>()) }
    var webOn by remember { mutableStateOf(true) }
    var showSettings by remember { mutableStateOf(false) }
    var backend by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        app.onAnswer = { messages = messages + Msg("assistant", it) }
        app.onBusy = { busy = it }
        onDispose { app.onAnswer = null; app.onBusy = null }
    }

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { input = it }
        }
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) speechLauncher.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
        })
    }
    val imageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            try {
                val raw = context.contentResolver.openInputStream(uri)?.readBytes() ?: return@rememberLauncherForActivityResult
                val bitmap = BitmapFactory.decodeByteArray(raw, 0, raw.size) ?: return@rememberLauncherForActivityResult
                val out = ByteArrayOutputStream()
                bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 82, out)
                val b64 = "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
                val q = input.ifBlank { "Bu görseli analiz et." }
                messages = messages + Msg("user", "📷 $q")
                input = ""
                app.startAnswer()
                send(q, b64, webOn)
            } catch (e: Exception) { messages = messages + Msg("assistant", "Görsel okunamadı: ${e.message}") }
        }
    }

    LaunchedEffect(Unit) { backend = getBackend() }

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Accent, onBackground = TextMain, onSurface = TextMain)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFE7E7DF)), contentAlignment = Alignment.Center) {
                        Text("J", color = Color.Black, fontWeight = FontWeight.Black, fontSize = 20.sp)
                    }
                    Spacer(Modifier.width(11.dp))
                    Column(Modifier.weight(1f)) {
                        Text("JARVIS", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(if (busy) "Yanıt hazırlıyor…" else "Hızlı Türkçe AI", color = Muted, fontSize = 11.sp)
                    }
                    IconButton(onClick = { messages = emptyList() }) { Icon(Icons.Default.Add, "Yeni sohbet") }
                    IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Ayarlar") }
                }

                if (messages.isEmpty()) {
                    Column(Modifier.fillMaxSize().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Text("Nasıl yardımcı olabilirim?", fontSize = 30.sp, fontWeight = FontWeight.Medium)
                        Spacer(Modifier.height(10.dp))
                        Text("Yaz, konuş veya görsel gönder.", color = Muted)
                        Spacer(Modifier.height(28.dp))
                        Suggestion("🔎 Güncel araştırma", "Web'den güncel bilgileri kaynaklarıyla bul") { input = "Bu konuyu güncel kaynaklarla araştır: " }
                        Suggestion("🧠 Hafızaya al", "JARVIS'e 'Hatırla: …' diyerek bilgi kaydet") { input = "Hatırla: " }
                        Suggestion("🌐 Sosyal profil", "Bir kullanıcı adını herkese açık platformlarda ara") { input = "@kullanici adını Instagram, TikTok, YouTube ve diğer platformlarda araştır." }
                    }
                } else {
                    LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                        items(messages) { m ->
                            Column {
                                Text(if (m.role == "user") "SEN" else "JARVIS", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(5.dp))
                                Text(m.text, fontSize = 15.sp, lineHeight = 23.sp)
                                if (m.role == "assistant") Text("🔊 Sesli oku", Modifier.padding(top = 6.dp).clickable { speak(m.text) }, color = Muted, fontSize = 11.sp)
                            }
                        }
                        if (busy) item { Row(verticalAlignment = Alignment.CenterVertically) { CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp); Spacer(Modifier.width(10.dp)); Text("JARVIS düşünüyor…", color = Muted, fontSize = 12.sp) } }
                        item { Spacer(Modifier.height(80.dp)) }
                    }
                }

                Column(Modifier.padding(12.dp)) {
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel).padding(7.dp), verticalAlignment = Alignment.Bottom) {
                        IconButton(onClick = { imageLauncher.launch("image/*") }, enabled = !busy) { Icon(Icons.Default.Image, "Görsel") }
                        IconButton(onClick = {
                            if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                speechLauncher.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
                                })
                            } else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }, enabled = !busy) { Icon(Icons.Default.Mic, "Ses") }
                        OutlinedTextField(value = input, onValueChange = { input = it }, Modifier.weight(1f), placeholder = { Text("JARVIS'e mesaj yaz…", color = Muted) }, colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color.Transparent, unfocusedBorderColor = Color.Transparent))
                        IconButton(onClick = {
                            if (input.isNotBlank() && !busy) {
                                val q = input
                                messages = messages + Msg("user", q)
                                input = ""
                                app.startAnswer()
                                send(q, null, webOn)
                            }
                        }) { Icon(Icons.Default.ArrowUpward, "Gönder") }
                    }
                    Row(Modifier.padding(horizontal = 8.dp, vertical = 5.dp)) {
                        Text(if (webOn) "● Web açık" else "○ Web kapalı", Modifier.clickable { webOn = !webOn }, color = Muted, fontSize = 10.sp)
                        Spacer(Modifier.weight(1f))
                        Text("AI • Hafıza • Görsel • Ses", color = Muted, fontSize = 10.sp)
                    }
                }
            }

            if (showSettings) AlertDialog(
                onDismissRequest = { showSettings = false },
                title = { Text("JARVIS ayarları") },
                text = { Column { Text("Backend URL", fontSize = 12.sp, color = Muted); OutlinedTextField(value = backend, onValueChange = { backend = it }); Spacer(Modifier.height(8.dp)); Text("Örnek: https://sunucun.com", fontSize = 11.sp, color = Muted) } },
                confirmButton = { TextButton(onClick = { saveBackend(backend); showSettings = false }) { Text("Kaydet") } }
            )
        }
    }
}

@Composable
fun Suggestion(title: String, sub: String, click: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { click() }, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(15.dp)) {
        Column(Modifier.padding(15.dp)) { Text(title, fontWeight = FontWeight.SemiBold); Text(sub, color = Muted, fontSize = 12.sp) }
    }
}
